package com.uniagustiniana.pedido;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Facutracion extends AppCompatActivity {
    private TextView valor_total;
    private TextView valor_unitario;
    private TextView iva;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facutracion);
        valor_total= findViewById(R.id.valor_total);
        valor_unitario = findViewById(R.id.valor_unitario);
        iva = findViewById(R.id.iva);

        public void mostrar(View view){
            Intent ()
        }
    }
}