package com.uniagustiniana.pedido;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private EditText cantidad_manzana;
    private EditText cantidad_pera;
    private EditText cantidad_pina;
    private Button facturacion;
    private TextView resultado1;
    private TextView resultado2;
    private TextView resultado3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cantidad_manzana = findViewById(R.id.cantidad_manzana);
        cantidad_pera = findViewById(R.id.cantidad_pera);
        cantidad_pina = findViewById(R.id.cantidad_pina);
        facturacion = findViewById(R.id.facturacion);
        resultado1 = findViewById(R.id.resultado1);
        resultado2 = findViewById(R.id.resultado2);
        resultado3 = findViewById(R.id.resultado3);
        facturacion.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Facutracion.class);
                i.putExtra("Factura", resultado1,resultado2,resultado3);
                startActivity(i);
            }
        });
    }

    public void valor_unitario_m(View view) {
        int manzana1 = Integer.parseInt((cantidad_manzana.getText().toString()));
        manzana1 *= 2000;
        int resultado1 = manzana1;
    }

    public void iva_m(View view) {
        int manzana2 = Integer.parseInt((cantidad_manzana.getText().toString()));
        manzana2 /= 19;
        int resultado2 = manzana2;
    }

    public void calcular_todo_m(View view) {
        int manzana3 = Integer.parseInt((cantidad_manzana.getText().toString()));
        manzana3 = manzana1 + manzana2;
        int resultado3 = manzana3;
    }

    public void valor_unitario_p(View view) {
        int pera1 = Integer.parseInt((cantidad_pera.getText().toString()));
        pera1 *= 2500;
        int resultado1 = pera1;
    }

    public void iva_p(View view) {
        int pera2 = Integer.parseInt((cantidad_pera.getText().toString()));
        pera2 /= 19;
        int resultado2 = pera2;
    }

    public void calcular_todo_p(View view) {
        int pera3 = Integer.parseInt((cantidad_pera.getText().toString()));
        pera3 = pera1 + pera2;
        int resultado3 = pera3;
    }

    public void valor_unitario_pi(View view) {
        int pina1 = Integer.parseInt((cantidad_pina.getText().toString()));
        pina1 *= 5000;
        int resultado1 = pina1;
    }

    public void iva_pi(View view) {
        int pina2 = Integer.parseInt((cantidad_pina.getText().toString()));
        pina2 /= 19;
        int resultado2 = pina2;
    }

    public void calcular_todo_pi(View view) {
        int pina3 = Integer.parseInt((cantidad_pina.getText().toString()));
        pina3 = pina1 + pina2;
        int resultado3 = pina3;
    }
}


